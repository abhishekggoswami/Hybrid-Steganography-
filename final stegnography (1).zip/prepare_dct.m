function [n1, n2, Grey_Image] = prepare_dct(Grey_Image, block_size)
    n1 = floor(size(Grey_Image,1) / block_size) * block_size;
    n2 = floor(size(Grey_Image,2) / block_size) * block_size;
    Grey_Image = imresize(Grey_Image, [n1, n2]);
end