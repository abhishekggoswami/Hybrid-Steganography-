function [Huffman_Code_Obtained, Huffman_Dictionary] = encode_huffman(Input_Image_Data)
    symbols = unique(Input_Image_Data);
    p = histc(Input_Image_Data(:), symbols) / numel(Input_Image_Data);
    [Huffman_Dictionary, ~] = huffmandict(symbols, p);
    Huffman_Code_Obtained = huffmanenco(Input_Image_Data, Huffman_Dictionary);
end