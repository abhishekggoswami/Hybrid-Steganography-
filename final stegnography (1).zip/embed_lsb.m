function Quantized_Image = embed_lsb(DCT_Image, Binary_Information)
    Quantized_Image = round(DCT_Image);
    Counter = 1;
    for ii = 1:numel(Quantized_Image)
        if Counter <= length(Binary_Information)
            LSB = mod(Quantized_Image(ii), 2);
            Quantized_Image(ii) = Quantized_Image(ii) + double(xor(LSB, Binary_Information(Counter)));
            Counter = Counter + 1;
        end
    end
end