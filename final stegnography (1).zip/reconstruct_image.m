function Decrypted_image = reconstruct_image(Quantized_Image, decrypted_data, dims)
    decrypted_img = double(reshape(decrypted_data, dims));
    Decrypted_image = (Quantized_Image - decrypted_img) + decrypted_img;
end