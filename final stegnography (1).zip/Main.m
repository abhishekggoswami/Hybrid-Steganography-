clc;
clear all;
close all;

[filename, pathname] = uigetfile({'*.*';'*.jpg';'*.png';'*.bmp'}, 'Pick a Cover Image');
Cover_Image = imread(fullfile(pathname, filename));

[filename, pathname] = uigetfile({'*.*';'*.jpg';'*.png';'*.bmp'}, 'Pick a Secret Image');
secret_img = imread(fullfile(pathname, filename));
[~,~,o]=size(secret_img);
if (o)==3
secret_img=rgb2gray(secret_img);
end
Image_Dimensions = [256 256];
Input_Image = imresize(secret_img, Image_Dimensions);
Input_Image_Data = reshape(Input_Image, [1, numel(Input_Image)]);

[Huffman_Code_Obtained, Huffman_Dictionary] = encode_huffman(Input_Image_Data);
Binary_Information = Huffman_Code_Obtained(:);
Embedding_Length = length(Binary_Information);

Cover_Image_Dimensions = [1024 1024];
Cover_Image = imresize(Cover_Image, Cover_Image_Dimensions);

Red_Part = Cover_Image(:,:,1);
Green_Part = Cover_Image(:,:,2);
Blue_Part = Cover_Image(:,:,3);
Grey_Image = im2double(Red_Part) * 255;

DCT_Block_Size = 8;
[n1, n2, Grey_Image] = prepare_dct(Grey_Image, DCT_Block_Size);
DCT_Image = blockproc(Grey_Image, [DCT_Block_Size DCT_Block_Size], @(block) dct2(block.data));

Quantized_Image = embed_lsb(DCT_Image, Binary_Information);

[timg, in] = confuse_image(Quantized_Image);

timg = timg';
[key, encrypted_data] = gwo_encrypt(timg);
himg = reshape(encrypted_data, [n1 n2]);

decrypted_data = gwo_decrypt(encrypted_data, key, in);
Decrypted_image = reconstruct_image(Quantized_Image, decrypted_data, [n1 n2]);

Steganographed_Image = blockproc((Decrypted_image), [DCT_Block_Size DCT_Block_Size], @(block) idct2(block.data));

Final_Steganographed_Image = cat(3, uint8(Steganographed_Image), Green_Part, Blue_Part);

DCT_Image_Recieved = blockproc(Steganographed_Image, [DCT_Block_Size DCT_Block_Size], @(block) dct2(block.data));
Quantized_Image_Recieved = round(DCT_Image_Recieved);



Extracted_Bits = mod(Quantized_Image_Recieved(:), 2);

Huffman_Decoded = huffmandeco(Extracted_Bits(1:Embedding_Length), Huffman_Dictionary);
% Reshaped_Decoded_Image = reshape(Huffman_Decoded, Image_Dimensions);
Reshaped_Decoded_Image = reshape(Huffman_Decoded, 256, []);

imwrite(Reshaped_Decoded_Image, "SecretImage.jpg");
figure;
tiledlayout(2,3);
nexttile; imshow(Input_Image); title("Image To be Hidden");
nexttile; imshow(Cover_Image); title("Cover Image");
nexttile; imshow(uint8(Quantized_Image)); title("Quantized Image");
nexttile; imshow((himg)); title("Encrypted image Image");

nexttile; imshow(Final_Steganographed_Image); title(" Decrypted Steganographed Image");
nexttile; imshow(Reshaped_Decoded_Image); title("Decoded Hidden Image");

  [mse1,psnr1]=PSNR_gray(double(Input_Image),double(Reshaped_Decoded_Image-1));
     ssim_val = ssim(uint8(Reshaped_Decoded_Image - 1), uint8(Input_Image));

disp("PSNR=");
disp(psnr1);


disp("SSIM=");
disp(ssim_val);





