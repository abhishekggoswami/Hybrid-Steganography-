function [key, encrypted_data] = gwo_encrypt(timg)
    SearchAgents = 10;
    MaxIter = 5;
    Dim = numel(timg);
    LB = 0; UB = 255;
    Wolves = rand(SearchAgents, Dim) * (UB - LB) + LB;
    Alpha = Wolves(1,:); Beta = Wolves(2,:); Delta = Wolves(3,:);
    fitness = @(key) sum(abs(diff(double(key))));

    for iter = 1:MaxIter
        a = 2 - iter * (2 / MaxIter);
        for i = 1:SearchAgents
            for j = 1:Dim
                A1 = 2 * a * rand - a; C1 = 2 * rand;
                D_alpha = abs(C1 * Alpha(j) - Wolves(i,j));
                X1 = Alpha(j) - A1 * D_alpha;

                A2 = 2 * a * rand - a; C2 = 2 * rand;
                D_beta = abs(C2 * Beta(j) - Wolves(i,j));
                X2 = Beta(j) - A2 * D_beta;

                A3 = 2 * a * rand - a; C3 = 2 * rand;
                D_delta = abs(C3 * Delta(j) - Wolves(i,j));
                X3 = Delta(j) - A3 * D_delta;

                Wolves(i,j) = (X1 + X2 + X3) / 3;
            end
            fitnessValues(i) = fitness(Wolves(i,:));
        end
        [~, idx] = sort(fitnessValues);
        Wolves = Wolves(idx,:);
        Alpha = Wolves(1,:); Beta = Wolves(2,:); Delta = Wolves(3,:);
    end
    key = uint8(mod(Alpha, 256));
    encrypted_data = bitxor(uint8(timg), key);
end