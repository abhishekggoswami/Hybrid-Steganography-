function decrypted_data = gwo_decrypt(encrypted_data, key, in)
    decrypted_data = bitxor(uint8(encrypted_data), uint8(key));
    s = length(decrypted_data);
    for m = s:-1:1
        t1 = decrypted_data(m);
        decrypted_data(m) = decrypted_data(in(m));
        decrypted_data(in(m)) = t1;
    end
end