function [timg, in] = confuse_image(img)
    r = 3.62;
    x(1) = 0.7;
    s = numel(img);
    for n = 1:s-1
        x(n+1) = r * x(n) * (1 - x(n));
    end
    [~, in] = sort(x);
    timg = img(:);
    for m = 1:s
        t1 = timg(m);
        timg(m) = timg(in(m));
        timg(in(m)) = t1;
    end
end